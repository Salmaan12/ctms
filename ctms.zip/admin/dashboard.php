<?php 

include('header-dashboard.php');


$server = "localhost";
$username = "root";
$database = "ctms";
$password = "";

// Create connection
$connection = new mysqli($server,$username,$password,$database);

// Check connection
if ($connection->connect_error) {
  echo "error ". $connection->connect_error;
}




;?>





<?php include('footer-bashboard.php');?>