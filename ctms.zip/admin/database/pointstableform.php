<?php

include 'connection.php';

$con = new mysqli($server, $user, $password, $database);


if ($con->connect_error) {
	die("Connection failed: " . $con->connect_error);
} 
else {
		$loosingPoints = $_POST['loosingPoints'];
		$winningPoints = $_POST['winningPoints'];
		$Team_ID = $_POST['Team_ID'];
		$noOfMatches = $_POST['noOfMatches'];
		$run_rate = $_POST['run_rate'];
        $tied = $_POST['tied'];
        $points = $_POST['points'];
        $Tournament_ID = $_POST['Tournament_ID'];

		$sql = "insert INTO `points_table`(`loosingPoints`, `winningPoints`, `team_ID`, `noOfMatches`, `run_rate`, `tied`, `points`, `tournament_ID`) VALUES ('$loosingPoints','$winningPoints','$Team_ID','$noOfMatches','$run_rate','$tied')";

		if ($con->query($sql)) {
			// header('Location: http://localhost/ctms/account.php');
			echo '<script> $(document).ready(function(){ toastr.success("points_table Successfully Added"); }); </script>';
		} else {
				echo '<script> $(document).ready(function(){ toastr.error("Error! points_table Not Added"); }); </script>';
		}
    }
	